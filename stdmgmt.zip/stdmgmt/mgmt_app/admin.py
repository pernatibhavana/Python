from django.contrib import admin
from .models import Gender,Studentmgmt,Stream,Degree
# Register your models here.

@admin.register(Studentmgmt)
class Studentmgmt(admin.ModelAdmin):
    ...

@admin.register(Gender)
class Genderadmin(admin.ModelAdmin):
    ...

@admin.register(Degree)
class Degreeadmin(admin.ModelAdmin):
    ...

@admin.register(Stream)
class Streamamdin(admin.ModelAdmin):
    ...

    