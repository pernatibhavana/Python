from django.urls import path
from . import views

urlpatterns = [
    path('',views.index),
    path('1/',views.success,name='success'),
    path('2/<int:pk>',views.details,name='display'),
    path('3/<int:pk>',views.update,name='edit'),
]