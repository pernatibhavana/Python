from django.db import models
from django_countries.fields import CountryField
from django.core.validators import MinValueValidator, MaxValueValidator 

class Gender(models.Model):
    name = models.CharField(max_length=20)

    def __str__(self):
        return self.name

    
class Degree(models.Model):
    Degree = models.CharField(max_length=50)

    def __str__(self):
        return self.Degree
    
class Stream(models.Model):
    Stream = models.CharField(max_length=50)

    def __str__(self):
        return self.Stream
    
# Create your models here.
INDIAN_STATES = [
    ('AP', 'Andhra Pradesh'),
    ('AR', 'Arunachal Pradesh'),
    ('AS', 'Assam'),
    ('BR', 'Bihar'),
    ('CG', 'Chhattisgarh'),
    ('GA', 'Goa'),
    ('GJ', 'Gujarat'),
    ('HR', 'Haryana'),
    ('HP', 'Himachal Pradesh'),
    ('JK', 'Jammu and Kashmir'),
    ('JH', 'Jharkhand'),
    ('KA', 'Karnataka'),
    ('KL', 'Kerala'),
    ('MP', 'Madhya Pradesh'),
    ('MH', 'Maharashtra'),
    ('MN', 'Manipur'),
    ('ML', 'Meghalaya'),
    ('MZ', 'Mizoram'),
    ('NL', 'Nagaland'),
    ('OD', 'Odisha'),
    ('PB', 'Punjab'),
    ('RJ', 'Rajasthan'),
    ('SK', 'Sikkim'),
    ('TN', 'Tamil Nadu'),
    ('TG', 'Telangana'),
    ('TR', 'Tripura'),
    ('UP', 'Uttar Pradesh'),
    ('UT', 'Uttarakhand'),
    ('WB', 'West Bengal'),
]

class Studentmgmt(models.Model):
    image = models.ImageField(upload_to='image/')
    first_name = models.CharField(max_length=20)
    middle_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    phone_no = models.PositiveBigIntegerField()
    age = models.IntegerField()
    gender = models.ForeignKey(Gender,on_delete=models.SET_NULL,null=True)
    email = models.EmailField(unique=True)
    address = models.TextField()
    country = CountryField(blank=True, null=True)
    state = models.CharField(max_length=2, choices=INDIAN_STATES, default='TS')
    aadhar_no = models.PositiveBigIntegerField(validators=[
            MinValueValidator(100000000000),  # Minimum 12-digit Aadhaar number
            MaxValueValidator(999999999999)   # Maximum 12-digit Aadhaar number
        ])

    # education details 
    ssc_percentage = models.FloatField(validators=[
        MinValueValidator(0),  # Minimum percentage
        MaxValueValidator(100)  # Maximum percentage
    ])
    inter_percentage = models.FloatField(validators=[
        MinValueValidator(0),  # Minimum percentage
        MaxValueValidator(100)  # Maximum percentage
    ])
    degree = models.ForeignKey(Degree,on_delete=models.CASCADE)
    stream = models.ForeignKey(Stream,on_delete=models.CASCADE)
    degree_percentage = models.FloatField(validators=[
        MinValueValidator(0),  # Minimum percentage
        MaxValueValidator(100)  # Maximum percentage
    ])


    def _str_(self):
        return f"{self.first_name} {self.last_name}"