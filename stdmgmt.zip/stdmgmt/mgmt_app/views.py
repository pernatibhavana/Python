from django.shortcuts import render,HttpResponse,redirect
from .forms import StudentmgmtForm
from .models import Studentmgmt
# Create your views here.
def index(request):
    form = StudentmgmtForm()
    if request.method == 'POST':
        form = StudentmgmtForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('success')
    return render(request,'index.html',{'form':form})

def details(request,pk):
    # Fetch all students from the database
    # students = Studentmgmt.objects.all()  # Adjust this query as needed (e.g., filter by criteria)
    students  = Studentmgmt.objects.get(id = pk)
    
    # Pass the students to the template
    context = {
        'students': students
    }
    
    return render(request, 'display.html', context)  # Replace 'your_template.html' with the actual path to your HTML file

def success(request):
    user = Studentmgmt.objects.all()
    context={
        'user':user
    }
    return render(request,'success.html',context)

def update(request,pk):
    data1 = Studentmgmt.objects.get(id=pk)
    if request.method == 'POST':
        form = StudentmgmtForm(request.POST,request.FILES,instance=data1)
        if form.is_valid():
            form.save()
            # return redirect('details_all', pk=data1.id)
            return render(request,'edit.html',{'form':form})
            # return redirect('only_name')
    else:
        form = StudentmgmtForm(instance=data1)
    return render(request,'edit.html',{'form':form})