from django import forms
from .models import Studentmgmt

class StudentmgmtForm(forms.ModelForm):
    class Meta:
        model =  Studentmgmt
        fields = '__all__'